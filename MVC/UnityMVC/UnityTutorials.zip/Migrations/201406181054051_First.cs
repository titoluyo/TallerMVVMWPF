namespace UnityTutorials.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    public partial class First : DbMigration
    {
        public override void Up()
        {

        }

        public override void Down()
        {
            DropTable("dbo.Articles");
        }
    }
}
