﻿This project is a dummy project that is really only here to provide a common set of source files, that are added
as links in both the Cinch.WPF and Cinch.SL projects.

Some of the files in this project are partial classes, with the other part within the Cinch.WPF and Cinch.SL projects. As such
it is perfectly normally for this project to not build correctly. You should instead build the Cinch.WPF and Cinch.SL projects,
which contain links to these source code files, as well as provide the specific platform missing pieces.
