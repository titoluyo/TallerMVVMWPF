﻿I am using the TestDriven .NET VS2008 addin which has a Personal edition which is free.
http://www.testdriven.net/

